library(testthat)
library(crupR)
#setwd("/project/wig/persia/CRUP_package/CRUP/tests/")

test_check("crupR")
